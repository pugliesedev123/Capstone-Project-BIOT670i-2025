The following scripts are run_with_summary variants tuned to each shark taxon.

Also included are taxa-config file variants for each individual run.
Please adjust your "input-config" variables to match the directory location of these files.
(e.g. ./tests/shark-experiment/taxa-hemipristis_serra.txt)

NOTE: All references to 'otodontine' are synonymous with 'otodontid' as are Cretolamna/Cretalamna. This is a lingering typo!